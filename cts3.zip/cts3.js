defineClass("BaseController", {
    viewDidLoad: function() {
        self.super().viewDidLoad();
        self.view().setBackgroundColor(require('UIColor').redColor());
    }
            }, {});